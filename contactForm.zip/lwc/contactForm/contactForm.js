// contactUsForm.js
import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createContactUsRecord from '@salesforce/apex/ContactUsController.createContactUsRecord';

export default class ContactUsForm extends LightningElement {
    @track name = '';
    @track email = '';
    @track phone = '';
    @track reason = '';
    @track description = '';

    handleNameChange(event) {
        this.name = event.target.value;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handlePhoneChange(event) {
        this.phone = event.target.value;
    }

    handleReasonChange(event) {
        this.reason = event.target.value;
    }

    handleDescriptionChange(event) {
        this.description = event.target.value;
    }

    handleSubmit() {
        // Perform client-side validations here
        
        createContactUsRecord({ 
            name: this.name, 
            email: this.email, 
            phone: this.phone, 
            reason: this.reason, 
            description: this.description 
        })
        .then(result => {
            // Handle success
            console.log('Contact Us record created successfully:', result);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Thank you! Your response has been submitted.',
                    variant: 'success'
                })
            );
        })
        .catch(error => {
            // Handle error
            console.error('Error creating Contact Us record:', error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'An error occurred while submitting your response. Please try again later.',
                    variant: 'error'
                })
            );
        });
    }
}