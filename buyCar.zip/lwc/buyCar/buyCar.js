import { LightningElement, track,wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getPriceRange from '@salesforce/apex/CarController.getPriceRange';
import getBrandName from '@salesforce/apex/CarController.getBrandName';
import getType from '@salesforce/apex/CarController.getType';
import getCarDetails from '@salesforce/apex/CarController.getCarDetails';

export default class CarSelector extends NavigationMixin(LightningElement) {
    @track showWelcomeScreen = true;
    @track showQuestionScreen = false;
    @track showResultsScreen = false;
    @track prices;
    @track budgetOptions = [];
    @track brandOptions = [];
    @track carTypeOptions = [];
    @track budget;
    @track brands;
    @track carType;

    @track filteredCars = [];

    @wire(getPriceRange) 
    wiredprices({ error, data }) {
       if (data) {
           this.prices = data;
           console.log('prices : ',this.prices);
      } else if (error) { 
          this.error = error;
          console.log('error : ',error);  
     }   }

     @wire(getBrandName) 
    wiredbrands({ error, data }) {
       if (data) {
           this.brands = data;
           console.log('brand: ',this.brands);
      } else if (error) { 
          this.error = error;
          console.log('error : ',error);  
     }   }

     @wire(getType) 
    wiredtypes({ error, data }) {
       if (data) {
           this.carType = data;
           console.log('type : ',this.carType);
      } else if (error) { 
          this.error = error;
          console.log('error : ',error);  
     }   }


    handleButtonClick() {
        this.showWelcomeScreen = false;
        this.showQuestionScreen = true;
         console.log('price1 : ',this.prices);
         if(this.prices.length>0) {
              for(var index = 0; index < this.prices.length ; index++) {
               this.budgetOptions.push({'label':this.prices[index],'value':this.prices[index]}) 
           }
            for(var index1 = 0; index1 < this.brands.length ; index1++) {
               this.brandOptions.push({'label':this.brands[index1],'value':this.brands[index1]}) 
           }
            for(var index2 = 0; index2 < this.carType.length ; index2++) {
               this.carTypeOptions.push({'label':this.carType[index2],'value':this.carType[index2]}) 
           }
            console.log('this.budgetOptions : ',this.budgetOptions);
         }else {
             console.log('array empty hai: ');
         }
        
    }

    handleBudgetChange(event) {
        this.budget = event.detail.value;
        console.log('this.carType : ',this.budget);
    }

    handleBrandChange(event) {
        this.brands = event.detail.value;
        console.log('this.carType : ',this.brands);
    }

    handleCarTypeChange(event) {
        this.carType = event.detail.value;
        console.log('this.carType : ',this.carType);
    }
    @track cars;
    @track showCarDetailModal = false;
    handleQuestionSubmit() {
        getCarDetails({brand:this.brands,budget : this.budget,carType: this.carType})
        .then(result => {
			this.cars = result;
			this.error = undefined;
            console.log('cars : ',this.cars);
            if(this.cars.length>0) {
                this.showQuestionScreen = false;
                this.showCarDetailModal = true;
            }
		})
		.catch(error => {
			this.error = error;
			this.cars = undefined;
            console.log('error : ',error);
		})
    }
}