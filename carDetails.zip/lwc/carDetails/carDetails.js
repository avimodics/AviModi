import { LightningElement, api } from 'lwc';
export default class CarDetails extends LightningElement {
@api allCarDetails;

connectedCallback() {
    console.log('this.allCarDetails',JSON.stringify(this.allCarDetails));
}
}